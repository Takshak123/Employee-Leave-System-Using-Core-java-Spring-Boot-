package com.example.ONLINE.EXAMINATION.SYSTEM.Services;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.User;
import com.example.ONLINE.EXAMINATION.SYSTEM.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public boolean registerUser(User user){
        try{
            userRepository.save(user);
            return true;
        }
        catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public User loginUser(String username, String password) {
        User validUser = userRepository.findByUsername(username);

        if (validUser!=null && validUser.getPassword().equals(password)){
            return validUser;
        }
        return null;
    }

    public long countStudent(){
        return userRepository.count();
    }

    public List<User> getAllStudent(){
        return userRepository.findAll().stream().filter(user -> "STUDENT".equalsIgnoreCase(user.getRole())).collect(Collectors.toList());
    }
}
