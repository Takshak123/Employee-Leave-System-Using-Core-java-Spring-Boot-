package com.example.ONLINE.EXAMINATION.SYSTEM.Services;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Question;
import com.example.ONLINE.EXAMINATION.SYSTEM.Repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    private QuestionRepository questionRepository;

    public List<Question> getAllQuestion() {
        return questionRepository.findAll();
    }

    public Question saveQuestion(Question question){
        return questionRepository.save(question);
    }

    public Question getQuestionById(Long id) {
        return questionRepository.findById(id).orElse(null);
    }

    public void deleteQuestionById(Long id) {
        questionRepository.deleteById(id);
    }
}
